﻿using System.Web;

namespace SimpleLogin
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
