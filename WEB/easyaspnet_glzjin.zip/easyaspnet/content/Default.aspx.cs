﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.UI;

namespace SimpleLogin
{

    public partial class Default : System.Web.UI.Page
    {
        public void button1Clicked(object sender, EventArgs args)
        {
            DirectoryInfo TheFolder = new DirectoryInfo("c:\\inetpub\\wwwroot\\static\\img\\");
            List<String> filesList = new List<String>();
            foreach (FileInfo NextFile in TheFolder.GetFiles())
            {
                filesList.Add(NextFile.Name);
            }
            Random random = new Random();
            image1.ImageUrl = "/ImgLoad.aspx?path=" + filesList[random.Next(filesList.Count)];
            button1.Text = "You clicked me";
        }
    }
}
