from flask import Flask, request,render_template_string,render_template
from jinja2 import Template

app = Flask(__name__)
app.config['SECRET_KEY']='sssssssSFSCFAS'
@app.route("/qaq")
def flag():
	name = request.args.get('name', 'null')
	t = "<!--ssssssti & a little trick --> P3's girlfirend is : {}<br><hr>".format(name)
	if "BJD" in render_template_string(t): #just a trick
		return "BJD in P3's gf's name !!!!!???"
	if "DJB" in render_template_string(t):
		return "DJB in P3's gf's name !!!!!???"
	return render_template_string(t)

@app.route("/")
def index():
	return render_template("index.html")

if __name__ == "__main__":
    app.run(host='0.0.0.0')