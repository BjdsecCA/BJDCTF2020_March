#!/bin/bash

export FLAG=BJD{where_is_my_girl_friend}

echo $FLAG > /flag

export FLAG=no
FLAG=no

rm -f /flag.sh
mysql -e "source /tmp/p3rh4ps.sql;" -uroot -proot
