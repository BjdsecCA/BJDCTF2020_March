<?php
error_reporting(0);
$FLAG=file_get_contents('/flag');
$con=mysqli_connect("localhost","root","root","p3rh4ps"); 
$username=$_POST['username'];
$password=$_POST['password'];

if ($_POST['password']==="OhyOuFOuNdit"){
    die("<div class='logo'>$FLAG</div>");
}
if(preg_match("/select|=|\"|\'|union|and|&|;|-|mid|like/i",$username)){
    die("<script>alert('Stop hacking!')</script>");
}
if(preg_match("/select|=|\"|\'|union|and|&|;|-|mid|like/i",$password)){
    die("<script>alert('Stop hacking!')</script>");
}
$sql="SELECT * FROM users WHERE username='$username' and password='$password'";

$result=mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

	if($row)
	{
        echo "<div class='logo'>BJD needs to be stronger</div>";
  	}
	else 
	{
	
	echo "<div class='logo'>You konw ,P3rh4ps needs a girl friend</div>";
	
	}

?>
