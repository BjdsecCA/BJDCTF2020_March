<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="initial-scale=1.0, user-scalable=no, width=device-width">
<title>SQLi</title>
<link rel="stylesheet" type="text/css" href="./files/reset.css">
<link rel="stylesheet" type="text/css" href="./files/scanboardLogin.css">
<link rel="stylesheet" type="text/css" href="./files/animsition.css">
</head>
<body>
	<div class="wp animsition" style="animation-duration: 0.8s; opacity: 1;">
		<div class="boardLogin">
			<div class="logo ">
				Welcome to BJDCTF's check in!
			</div>

			<form action="./index.php" method="post">
				<div class="inpGroup">
					<span class="loginIco1"></span>
					<input type="text" name="username" placeholder="请输入您的用户名">
				</div>
				<div class="prompt">
					<p class="error">用户名错误或不存在</p>
				</div>

				<div class="inpGroup">
					<span class="loginIco2"></span>
					<input type="password" name="password" placeholder="请输入您的密码">
				</div>
				<div class="prompt">
					<p class="success">输入正确</p>
				</div>
				<button class="submit">登录</button>
			</form>
			<br><br>
			<?php require_once 'check.php';?>
		</div>
		
	</div>
	<div id="particles-js"><canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="3360" height="1780"></canvas></div>

<script type="text/javascript" src="./files/jquery.min.js"></script>
<script type="text/javascript" src="./files/jquery.animsition.js"></script>
<script src="./files/particles.min.js"></script>
<script src="./files/app.js"></script>
<script type="text/javascript">
	$(".animsition").animsition({
	    inClass               :   'fade-in',
	    outClass              :   'fade-out',
	    inDuration            :    800,
	    outDuration           :    1000,
	    linkElement           :   '.animsition-link',

	    loading               :    false,
	    loadingParentElement  :   'body',
	    loadingClass          :   'animsition-loading',
	    unSupportCss          : [ 'animation-duration',
	                              '-webkit-animation-duration',
	                              '-o-animation-duration'
	                            ],


	    overlay               :   false,

	    overlayClass          :   'animsition-overlay-slide',
	    overlayParentElement  :   'body'
  	});
</script>

</body></html>
